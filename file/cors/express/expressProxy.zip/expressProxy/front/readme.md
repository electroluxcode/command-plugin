npm install http-server -g   


http-server -p 8088  --cors

refer:https://www.npmjs.com/package/http-server