## 这是本地运行的版本，最蠢

```shell

npm install
访问 api 访问 localhost:8010/api/get?id=23
localhost:8010/mock.html


```