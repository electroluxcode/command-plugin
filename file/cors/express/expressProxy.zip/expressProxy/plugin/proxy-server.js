// 添加依赖
const express = require('express');
const app = express();
const { createProxyMiddleware } = require('http-proxy-middleware');
var path = require('path');


// 官方实例的翻译，有改动

// 代理中间件选项
// const options = {
//   target: 'http://localhost:8086', // 目标地址

//   // 把目标主机获取到的 Host 替换成目标地址
//   // 当为 true 时，目标主机获取到的 Host 端口为 8086，反之为3000
//   changeOrigin: false,

//   ws: true, // 是否代理 WebSockets
//   pathRewrite: {
//     '^/api/old-path': '/api/new-path', // 重写路径
//     '^/api/remove/path': '/path', // 移除中间的路径
//   },
//   router: {
//     // 当 request.headers.host == 'dev.localhost:3000' 时,
//     // 把目标地址 转换成 'http://localhost:5500'
//     'localhost:8086': 'http://localhost:5500',
//   },
// };

// // 创建代理 (without context)
// const exampleProxy = createProxyMiddleware(options);

// 挂载 `exampleProxy` 到服务器
// app.use('/api', exampleProxy);

// ---------------
// 符合自己需求的写法

// target 是 外部的 链接 
const optionProject = {
  target: 'http://localhost:8010',
  changeOrigin: false,
  ws: true,
  pathRewrite: {
    '^/project-name': '',
  },
};
const myProxy = createProxyMiddleware(optionProject);


app.use(express.static(path.join(__dirname, 'views'))); //指定静态文件目录
app.use('/project-name', myProxy);
app.listen(8011);