## 这是挂了别人的代理，有效，

虽然跟nginx一样要放到指定目录下面，但是目前来看这是比较好的方案了

```shell

npm install
访问 api 访问 localhost:8011/api/get?id=23
localhost:8011/plugin.html


```